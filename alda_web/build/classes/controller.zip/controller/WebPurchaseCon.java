package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;


public class WebPurchaseCon implements Command {

	@Override
	public void command(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		PrintWriter script = response.getWriter();
		
		if (request.getMethod().equals("POST")) {
			
			String id = (String) session.getAttribute("id");
			
			if (id == null) {
				script.write("Login");
				script.flush();
				
				return;
			}
			
			String price = request.getParameter("price");
			String product = request.getParameter("product");
			
			if(price == null) {
				script.write("Fail");
				
				return;
			} else {
				session.setAttribute("price", price);
				session.setAttribute("product", product);
				
				script.write("Success");
				
				return;
			}
		} else if(request.getMethod().equals("GET")) {
			try {				
				String price = session.getAttribute("price").toString();
				String product = session.getAttribute("product").toString();
				
				script.write("{\"price\":\"" + price + "\", \"product\":\"" + product + "\"}");
				script.flush();
				
				return;
			} catch(Exception e) {
				e.printStackTrace();
				
				script.write("Fail");
				script.flush();
				
				return;
			}
						
		}
	}

}
