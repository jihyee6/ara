package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class JoinTypeCon implements Command {

	@Override
	public void command(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		PrintWriter script = response.getWriter();
		
		String token = request.getParameter("token");
		String join_type = request.getParameter("join_type");
		String origin_page = request.getParameter("origin_page");
		
		if (join_type.length() == 0) {
			script.write("joinType");
		} else {
			if(join_type.equals("app")) {
				script.write("join");
				session.setAttribute("join_type", join_type);
			} else {
				if (token.length() == 0) {
					script.write("joinToken");
				} else {
					script.write("join");
					session.setAttribute("token", token);
					session.setAttribute("join_type", join_type);
					session.setAttribute("origin_page", origin_page);
				}
			}
		}	
	}

}
