package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class JoinInfoCon implements Command {

	@Override
	public void command(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		PrintWriter script = response.getWriter();
		
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		
		String token = request.getParameter("token");
		String join_type = request.getParameter("join_type");
		
		
		if (name.length() == 0) {
			script.write("joinName");
		} else if (phone.length() == 0) {
			script.write("joinPhone");
		} else {
			script.write("joinInfo");
			session.setAttribute("name", name);
			session.setAttribute("phone", phone);
			session.setAttribute("join_type", join_type);
			
			if (!join_type.equals("app")) {
				session.setAttribute("token", token);
			}
		} 		
	}

}
