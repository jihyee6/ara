package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class WebLoginCon implements Command {

	@Override
	public void command(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		PrintWriter script = response.getWriter();

		String id = request.getParameter("id");
		System.out.println(id);
		// String pw = request.getParameter("pw");
		String login_type = request.getParameter("login_type");

		if (id.length() == 0) {
			script.write("loginId");
		} else if (login_type.length() == 0) {
			script.write("loginType");
		} else {
			script.write("login");

			session.removeAttribute("join_type");
			session.removeAttribute("token");
			session.removeAttribute("origin_page");

			session.removeAttribute("name");
			session.removeAttribute("phone");

			session.setAttribute("id", id);
			session.setAttribute("login_type", login_type);
		}
		
//		if (id.length() == 0) { 
//			script.write("loginId"); script.flush(); 
//			//}
//			System.out.println("idnull"); 
//		} else if (pw.length() == 0) {
//		  script.write("loginPw"); script.flush(); 
//		  // System.out.println("pwnull"); 
//		} else if (id.equals("inipay") && pw.equals("inipay00!")) {
//			  
//		  script.write("inipay"); 
//		  session.setAttribute("id", id);
//		  session.setAttribute("name", "이니시스"); 
//		  script.flush(); 
//		  
//		} else {
//		  script.write("loginFailed"); script.flush(); 
//	    }
		 

	}

}
