package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class FindLoginInfoCon implements Command {

	@Override
	public void command(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		PrintWriter script = response.getWriter();
		
		String user_name = request.getParameter("user_name");
		String phone_no = request.getParameter("phone_no");
		String gender = request.getParameter("gender");
		String birthYear = request.getParameter("birthYear");
		
		session.setAttribute("user_name", user_name);
		session.setAttribute("phone_no", phone_no);
		session.setAttribute("gender", gender);
		session.setAttribute("birthYear", birthYear);
		
	}

}